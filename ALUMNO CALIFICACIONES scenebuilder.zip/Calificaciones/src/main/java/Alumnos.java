public class Alumnos {
    private String nombre;
    private String apellidos;
    private int ad;
    private int sge;
    private int di;
    private int pmdm;
    private int psp;
    private int eie;
    private int hlc;

    // Constructor
    public Alumnos(String nombre, String apellidos, int ad, int sge, int di, int pmdm, int psp, int eie, int hlc) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.ad = ad;
        this.sge = sge;
        this.di = di;
        this.pmdm = pmdm;
        this.psp = psp;
        this.eie = eie;
        this.hlc = hlc;
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getAd() {
        return ad;
    }

    public void setAd(int ad) {
        this.ad = ad;
    }

    public int getSge() {
        return sge;
    }

    public void setSge(int sge) {
        this.sge = sge;
    }

    public int getDi() {
        return di;
    }

    public void setDi(int di) {
        this.di = di;
    }

    public int getPmdm() {
        return pmdm;
    }

    public void setPmdm(int pmdm) {
        this.pmdm = pmdm;
    }

    public int getPsp() {
        return psp;
    }

    public void setPsp(int psp) {
        this.psp = psp;
    }

    public int getEie() {
        return eie;
    }

    public void setEie(int eie) {
        this.eie = eie;
    }

    public int getHlc() {
        return hlc;
    }

    public void setHlc(int hlc) {
        this.hlc = hlc;
    }


    public double calcularPromedio() {
        return (ad + sge + di + pmdm + psp + eie + hlc) / 7.0;
    }


    @Override
    public String toString() {
        return "Nombre: " + nombre + " " + apellidos +
                "\nNotas: " +
                "\nAD: " + ad +
                "\nSGE: " + sge +
                "\nDI: " + di +
                "\nPMDM: " + pmdm +
                "\nPSP: " + psp +
                "\nEIE: " + eie +
                "\nHLC: " + hlc +
                "\nPromedio: " + calcularPromedio();
    }
}
