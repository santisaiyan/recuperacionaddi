module org.example.calificaciones {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens org.example.calificaciones to javafx.fxml;
    exports org.example.calificaciones;
}